import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("65437489-49ba-48c3-bc66-cb6a912a0e18")
public class Entreprise {
    @mdl.prop
    @objid ("aa5c4f0d-bafb-4f62-9fb9-e369565c8f31")
    private static Entreprise entreprise;

    @objid ("63522a4f-1ca4-43b2-9845-76f233b1be14")
    public List<Employe> employee = new ArrayList<Employe> ();

    @objid ("1f62abb8-30f1-4b48-8c64-6ccbdad92b1d")
    public List<Projet> projets = new ArrayList<Projet> ();

    @objid ("0007c508-30c3-44aa-8dff-54cd42223df3")
    public void Connexion(final int id, final String mot_de_passe) {
    }

    @objid ("cb59fc28-da4b-4dec-9ba8-e3bf8908ba29")
    public void Deconnexion(final int id, final String mot_de_passe) {
    }

}
