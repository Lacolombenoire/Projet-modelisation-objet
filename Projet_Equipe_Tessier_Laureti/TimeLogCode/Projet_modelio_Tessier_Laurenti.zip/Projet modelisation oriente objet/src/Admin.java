import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("82ac72eb-ae3c-491d-b498-272e949675b2")
public class Admin extends Employe {
    @objid ("1901bc22-b046-4a70-9efd-16a6e7d99d79")
    public void Changer_employer_projet() {
    }

    @objid ("786d7a60-3d75-4ddc-ae14-55afd6835177")
    public void Enlever_employe_projet() {
    }

    @objid ("6f2d9736-d094-475b-9737-4321696ce9c7")
    public void Ajouter_employe_projet() {
    }

    @objid ("0e7c3b2c-102a-4641-8448-cc56781795d5")
    public void Modifier_employer() {
    }

    @objid ("c0b12b24-040d-4080-a440-719da0a3047b")
    public void Afficher_projets() {
    }

    @objid ("330ec1d0-affc-4246-881d-4e9952416a34")
    public void Supprimer_projet() {
    }

    @objid ("457f37a9-c5d0-43dd-bec5-c0d9bf52056f")
    public void Creer_projet() {
    }

    @objid ("ec3836c3-3132-46c8-b8ee-8bda455b4924")
    public void Modifier_projet() {
    }

    @objid ("d5d1ec5b-a7b6-4197-9e7f-922f86d77830")
    public void Creer_discipline() {
    }

    @objid ("99f0b3a3-0588-47e9-827d-232091460285")
    public void Modifier_discipline() {
    }

    @objid ("b1925b43-90ca-4760-8cf0-227d5a2d6d75")
    public void Afficher_rapport_employee() {
    }

    @objid ("7e88082f-c797-4159-badc-8373346abc22")
    public void Afficher_rapport_projet() {
    }

}
