import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("1a191a2b-236a-4890-a8fc-997e5dee2949")
public class Nombre_heure {
    @mdl.prop
    @objid ("ddfe347f-43bb-4e91-b50b-57ea5a2d4edf")
    private int nbr_heure;

    @mdl.propgetter
    public int getNbr_heure() {
        // Automatically generated method. Please do not modify this code.
        return this.nbr_heure;
    }

    @mdl.propsetter
    public void setNbr_heure(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.nbr_heure = value;
    }

}
