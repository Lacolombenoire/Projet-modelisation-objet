import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f64ef164-7dab-47e2-917f-fb177706e2b4")
public class Poste {
    @mdl.prop
    @objid ("99e91557-aa34-4df7-a033-c18e28209856")
    private String nom;

    @mdl.propgetter
    public String getNom() {
        // Automatically generated method. Please do not modify this code.
        return this.nom;
    }

    @mdl.propsetter
    public void setNom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.nom = value;
    }

    @mdl.prop
    @objid ("9001cf74-3c7a-43af-b144-2ab24bc4333c")
    private Discipline discipline;

    @mdl.propgetter
    public Discipline getDiscipline() {
        // Automatically generated method. Please do not modify this code.
        return this.discipline;
    }

    @mdl.propsetter
    public void setDiscipline(final Discipline value) {
        // Automatically generated method. Please do not modify this code.
        this.discipline = value;
    }

    @objid ("75d4faa7-8704-4656-ae10-d18ba40062f8")
    public List<Employe> Liste_employees = new ArrayList<Employe> ();

}
