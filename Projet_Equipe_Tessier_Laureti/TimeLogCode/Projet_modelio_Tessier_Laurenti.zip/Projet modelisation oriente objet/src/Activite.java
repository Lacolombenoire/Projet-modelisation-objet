import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("302c1559-1470-48a5-8766-ab0aaffba127")
public class Activite {
    @mdl.prop
    @objid ("ecf986b3-c0cf-4146-b0f1-97a2cdbf808f")
    private Date Date_debut ;

    @mdl.propgetter
    public Date getDate_debut () {
        // Automatically generated method. Please do not modify this code.
        return this.Date_debut ;
    }

    @mdl.propsetter
    public void setDate_debut (final Date value) {
        // Automatically generated method. Please do not modify this code.
        this.Date_debut  = value;
    }

    @mdl.prop
    @objid ("ee9dc6e0-2f87-4fd9-85b4-a3726a2189a6")
    private Date Date_debut;

    @mdl.propgetter
    public Date getDate_debut() {
        // Automatically generated method. Please do not modify this code.
        return this.Date_debut;
    }

    @mdl.propsetter
    public void setDate_debut(final Date value) {
        // Automatically generated method. Please do not modify this code.
        this.Date_debut = value;
    }

    @mdl.prop
    @objid ("c1a90fef-0c14-4833-9b0b-76970741b2b7")
    private String Nom;

    @mdl.propgetter
    public String getNom() {
        // Automatically generated method. Please do not modify this code.
        return this.Nom;
    }

    @mdl.propsetter
    public void setNom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.Nom = value;
    }

    @mdl.prop
    @objid ("52315bad-3e17-460e-a470-92cd438b3b2e")
    private Projet projet;

    @mdl.propgetter
    public Projet getProjet() {
        // Automatically generated method. Please do not modify this code.
        return this.projet;
    }

    @mdl.propsetter
    public void setProjet(final Projet value) {
        // Automatically generated method. Please do not modify this code.
        this.projet = value;
    }

    @objid ("610c2a9b-1606-432a-b678-6396c27b4d2b")
    public Discipline discipline;

    @objid ("97d708c7-8daa-4cce-8e4a-905b9266040b")
    private void Calculer_temps_total() {
    }

    @objid ("cf4a49b8-ec87-4daf-a643-8d5c2b0c57c8")
    public void Terminer_activité() {
    }

    @objid ("c62e0040-c720-4f1f-a3c6-157934640d5a")
    public Activite(final String Nom, final Poste poste) {
    }

}
