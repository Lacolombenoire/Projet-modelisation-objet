import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("db718463-834d-4067-a8d7-8866830770e5")
public class Discipline {
    @mdl.prop
    @objid ("1a32ba56-c44e-446d-9ec7-cdb00abe8a84")
    private String nom;

    @mdl.propgetter
    public String getNom() {
        // Automatically generated method. Please do not modify this code.
        return this.nom;
    }

    @mdl.propsetter
    public void setNom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.nom = value;
    }

    @objid ("0ea37539-bd44-4e88-b0ee-21d9b300605b")
    public List<Poste> postes = new ArrayList<Poste> ();

    @mdl.prop
    @objid ("cd0ad76e-81c3-49b8-8b8d-a296d7921e82")
    private List<Activite> Liste_activite = new ArrayList<Activite> ();

    @mdl.propgetter
    public List<Activite> getListe_activite() {
        // Automatically generated method. Please do not modify this code.
        return this.Liste_activite;
    }

    @mdl.propsetter
    public void setListe_activite(final List<Activite> value) {
        // Automatically generated method. Please do not modify this code.
        this.Liste_activite = value;
    }

}
