import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("29148ee5-4ce1-4892-b37e-c28f6d79f9ad")
public class Projet {
    @mdl.prop
    @objid ("6659efc3-9d4e-4a50-bdd0-1c37cbc31cd1")
    private String Date_debut;

    @mdl.propgetter
    public String getDate_debut() {
        // Automatically generated method. Please do not modify this code.
        return this.Date_debut;
    }

    @mdl.propsetter
    public void setDate_debut(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.Date_debut = value;
    }

    @mdl.prop
    @objid ("403a00d4-7e55-4f3d-b343-cace82f11776")
    private String Nom;

    @mdl.propgetter
    public String getNom() {
        // Automatically generated method. Please do not modify this code.
        return this.Nom;
    }

    @mdl.propsetter
    public void setNom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.Nom = value;
    }

    @mdl.prop
    @objid ("09cd3906-e18f-4152-92ae-c3dfd0beb56e")
    private String Date_fin;

    @mdl.propgetter
    public String getDate_fin() {
        // Automatically generated method. Please do not modify this code.
        return this.Date_fin;
    }

    @mdl.propsetter
    public void setDate_fin(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.Date_fin = value;
    }

    @mdl.prop
    @objid ("cf507dcf-7bbb-46b3-b977-ba26d92fea9f")
    private String Numero_identification;

    @mdl.propgetter
    public String getNumero_identification() {
        // Automatically generated method. Please do not modify this code.
        return this.Numero_identification;
    }

    @mdl.propsetter
    public void setNumero_identification(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.Numero_identification = value;
    }

    @objid ("6af3f71b-a2b4-401b-8a8a-1e5dfad5a9f8")
    public List<Activite> Liste_activite = new ArrayList<Activite> ();

    @objid ("ec3e7b6d-d1be-4439-a176-d1685fa4566c")
    public List<Employe> liste_employes = new ArrayList<Employe> ();

    @mdl.prop
    @objid ("78995f91-9078-40e2-9d69-d48b7f0acfa1")
    private Entreprise entreprise;

    @mdl.propgetter
    public Entreprise getEntreprise() {
        // Automatically generated method. Please do not modify this code.
        return this.entreprise;
    }

    @mdl.propsetter
    public void setEntreprise(final Entreprise value) {
        // Automatically generated method. Please do not modify this code.
        this.entreprise = value;
    }

}
