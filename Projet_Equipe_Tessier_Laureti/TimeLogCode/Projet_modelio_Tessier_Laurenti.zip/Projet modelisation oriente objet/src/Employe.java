import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("94e57bcc-b7b1-4697-a088-29a93461c5d3")
public class Employe {
    @mdl.prop
    @objid ("a725101a-8ccf-4443-a9e6-37b479a46c4d")
    private int taux_horaire;

    @mdl.propgetter
    public int getTaux_horaire() {
        // Automatically generated method. Please do not modify this code.
        return this.taux_horaire;
    }

    @mdl.propsetter
    public void setTaux_horaire(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.taux_horaire = value;
    }

    @mdl.prop
    @objid ("82a9078d-dedf-40e2-9239-5f9bc5c7b90d")
    private String taux_supplementaire;

    @mdl.propgetter
    public String getTaux_supplementaire() {
        // Automatically generated method. Please do not modify this code.
        return this.taux_supplementaire;
    }

    @mdl.propsetter
    public void setTaux_supplementaire(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.taux_supplementaire = value;
    }

    @mdl.prop
    @objid ("fe2ca7b0-a2d2-4991-b2d7-760afbbe6ef3")
    private String numero_identifiant;

    @mdl.propgetter
    public String getNumero_identifiant() {
        // Automatically generated method. Please do not modify this code.
        return this.numero_identifiant;
    }

    @mdl.propsetter
    public void setNumero_identifiant(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.numero_identifiant = value;
    }

    @mdl.prop
    @objid ("bfc39f31-aa4f-4aa6-9c42-5be349c85195")
    private String nom;

    @mdl.propgetter
    public String getNom() {
        // Automatically generated method. Please do not modify this code.
        return this.nom;
    }

    @mdl.propsetter
    public void setNom(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.nom = value;
    }

    @mdl.prop
    @objid ("c78ac3b5-5688-4afe-80b1-e4992c0040d4")
    private Date date_embauche;

    @mdl.propgetter
    public Date getDate_embauche() {
        // Automatically generated method. Please do not modify this code.
        return this.date_embauche;
    }

    @mdl.propsetter
    public void setDate_embauche(final Date value) {
        // Automatically generated method. Please do not modify this code.
        this.date_embauche = value;
    }

    @mdl.prop
    @objid ("27841161-8326-4c78-aa1e-a3007cde784e")
    private String date_depart;

    @mdl.propgetter
    public String getDate_depart() {
        // Automatically generated method. Please do not modify this code.
        return this.date_depart;
    }

    @mdl.propsetter
    public void setDate_depart(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.date_depart = value;
    }

    @mdl.prop
    @objid ("a2c8e3de-a3ae-418a-a900-134737e2c4d1")
    private String numero_assurance_social;

    @mdl.propgetter
    public String getNumero_assurance_social() {
        // Automatically generated method. Please do not modify this code.
        return this.numero_assurance_social;
    }

    @mdl.propsetter
    public void setNumero_assurance_social(final String value) {
        // Automatically generated method. Please do not modify this code.
        this.numero_assurance_social = value;
    }

    @mdl.prop
    @objid ("ca1c5b58-73b7-4fc3-928b-a2c7ed6334d4")
    private Entreprise entreprise;

    @mdl.propgetter
    public Entreprise getEntreprise() {
        // Automatically generated method. Please do not modify this code.
        return this.entreprise;
    }

    @mdl.propsetter
    public void setEntreprise(final Entreprise value) {
        // Automatically generated method. Please do not modify this code.
        this.entreprise = value;
    }

    @mdl.prop
    @objid ("1e73ca33-c603-46d7-8cde-5e0c821bf2b5")
    private Projet projet;

    @mdl.propgetter
    public Projet getProjet() {
        // Automatically generated method. Please do not modify this code.
        return this.projet;
    }

    @mdl.propsetter
    public void setProjet(final Projet value) {
        // Automatically generated method. Please do not modify this code.
        this.projet = value;
    }

    @mdl.prop
    @objid ("4ba334a2-5afd-465d-b234-5e6e0cd7d249")
    private Poste poste;

    @mdl.propgetter
    public Poste getPoste() {
        // Automatically generated method. Please do not modify this code.
        return this.poste;
    }

    @mdl.propsetter
    public void setPoste(final Poste value) {
        // Automatically generated method. Please do not modify this code.
        this.poste = value;
    }

    @objid ("6fb6d855-b7e9-4944-825c-98777c5b231a")
    public List<Activite> Liste_activite = new ArrayList<Activite> ();

    @objid ("840bb0c4-5a74-49df-afea-0af466062040")
    public Activite activite_en_cours;

    @objid ("451e65f7-ba46-4158-904f-146e1ed60b0b")
    public void Consulter_information() {
    }

    @objid ("b96f12dc-eddc-4826-bdbc-2b1a6d182ca8")
    public void Consulter_information_salariale() {
    }

    @objid ("2cc001ab-f4a7-4795-b20d-ffb44886db47")
    public void Commencer_activité() {
    }

}
