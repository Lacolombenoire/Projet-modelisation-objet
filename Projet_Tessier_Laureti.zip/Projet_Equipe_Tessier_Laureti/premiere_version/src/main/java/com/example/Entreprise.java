package com.example;
import java.util.ArrayList;


public class Entreprise {
   
    public static Entreprise entreprise = new Entreprise();

    
    public ArrayList<Employe> employee = new ArrayList<Employe> ();

   
    public ArrayList<Projet> projets = new ArrayList<Projet> ();

   
    public void Connexion(final int id, final String mot_de_passe) {
    }

   
    public void Deconnexion(final int id, final String mot_de_passe) {
    }

}