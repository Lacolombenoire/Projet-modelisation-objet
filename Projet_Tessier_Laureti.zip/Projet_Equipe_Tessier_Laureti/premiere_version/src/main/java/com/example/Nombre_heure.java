package com.example;
public class Nombre_heure {
    
    private int nbr_heure;

  
    public int getNbr_heure() {
        // Automatically generated method. Please do not modify this code.
        return this.nbr_heure;
    }

 
    public void setNbr_heure(final int value) {
        // Automatically generated method. Please do not modify this code.
        this.nbr_heure = value;
    }

}
