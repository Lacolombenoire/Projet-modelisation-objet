package com.example;

import java.util.Date;

public class Admin extends Employe {

    public Admin(int taux_horaire, int taux_supplementaire, String nom, int numero_identifiant, int numero_assurance_social, Date date_embauche, Poste poste, Projet projet) {
        super(taux_horaire, taux_supplementaire, nom, numero_identifiant, numero_assurance_social, date_embauche, poste, projet);
    }

    public void Changer_employer_projet() {
    }

   
    public void Enlever_employe_projet() {
    }

    
    public void Ajouter_employe_projet() {
    }

   
    public void Modifier_employer() {
    }

   
    public void Afficher_projets() {
    }

    
    public void Supprimer_projet() {
    }


    public void Creer_projet() {
    }

   
    public void Modifier_projet() {
    }

    
    public void Creer_discipline() {
    }

   
    public void Modifier_discipline() {
    }

    
    public void Afficher_rapport_employee() {
    }

    
    public void Afficher_rapport_projet() {
    }

}
